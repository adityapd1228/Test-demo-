import streamlit as st
import pandas as pd
from datetime import datetime
from io import BytesIO
from rapidfuzz import fuzz

st.set_page_config(page_title="NAVA Analytics AI", layout="wide")

def get_user():
    return {"user_id": "demo", "email": "demo@nava-analytics.ai", "plan": "starter",
            "uploads_this_period": 0, "terms_version": "2025-08-12", "terms_accepted_at": "2025-08-12T00:00:00Z"}

FEATURES = {
  "basic":  {"uploads": 1,  "compare": False, "dcma": False, "narrative": False, "pdf": False},
  "starter":{"uploads": 10, "compare": True,  "dcma": False, "narrative": False,  "pdf": True},
  "pro":    {"uploads": -1, "compare": True,  "dcma": True,  "narrative": True,  "pdf": True},
  "ent":    {"uploads": -1, "compare": True,  "dcma": True,  "narrative": True,  "pdf": True}
}

def can(user, feature): return FEATURES[user["plan"]].get(feature, False)

try:
    from nava_legal.consent_module import require_consent
except Exception:
    def require_consent(user): pass

st.sidebar.title("NAVA Analytics AI (Demo)")
user = get_user()
require_consent(user)

st.title("Compare Schedules — Demo")
if not can(user, "compare"):
    st.warning("Compare is available on Starter and above. Please upgrade.")
else:
    baseline = st.file_uploader("Baseline (.xer)", type=["xer"], key="bl")
    updates = st.file_uploader("Updates (.xer) — select 1..N", type=["xer"], accept_multiple_files=True, key="ups")

    def parse_demo(file):
        return pd.DataFrame({
            "ActivityID": ["A100","A200","A300"],
            "ActivityName": ["Mobilize","Foundation","Steel"],
            "Start": pd.to_datetime(["2025-01-02","2025-01-10","2025-02-01"]),
            "Finish": pd.to_datetime(["2025-01-05","2025-01-25","2025-02-20"]),
            "TotalFloatDays": [5, 10, -2],
        })

    def compare(bdf, udf, label):
        m = bdf.merge(udf, on="ActivityID", how="outer", suffixes=("_BL","_UP"))
        m["UpdateLabel"] = label
        m["Status"] = "CHANGED"
        m.loc[m["ActivityName_BL"].isna(), "Status"] = "ADDED"
        m.loc[m["ActivityName_UP"].isna(), "Status"] = "DELETED"
        for c in ["Start","Finish"]:
            m[f"Delta_{c}_days"] = (m[f"{c}_UP"] - m[f"{c}_BL"]).dt.days
        m["Delta_Float_days"] = m["TotalFloatDays_UP"] - m["TotalFloatDays_BL"]
        def is_crit(x): 
            try: return float(x) <= 0
            except: return False
        m["Critical_BL"] = m["TotalFloatDays_BL"].apply(is_crit)
        m["Critical_UP"] = m["TotalFloatDays_UP"].apply(is_crit)
        m["CriticalityChange"] = m.apply(
            lambda r: "NC→C" if (r["Critical_BL"]==False and r["Critical_UP"]==True) else
                      ("C→NC" if (r["Critical_BL"]==True and r["Critical_UP"]==False) else "—"),
            axis=1
        )
        return m

    if st.button("Analyze", disabled=not (baseline and updates)):
        bl_df = parse_demo(baseline)
        from io import BytesIO
        import pandas as pd
        sheets = {}
        sums = []
        for f in updates:
            up_df = parse_demo(f)
            comp = compare(bl_df, up_df, f.name)
            sheets[f.name] = comp
            sums.append({
                "Update": f.name,
                "Activities": len(comp),
                "Flip to Critical": int((comp["CriticalityChange"]=="NC→C").sum()),
                "Added": int((comp["Status"]=="ADDED").sum()),
                "Deleted": int((comp["Status"]=="DELETED").sum())
            })
            st.subheader(f"Baseline vs {f.name}")
            st.dataframe(comp[["ActivityID","ActivityName_BL","ActivityName_UP","Status",
                               "Delta_Start_days","Delta_Finish_days","Delta_Float_days","CriticalityChange"]],
                         use_container_width=True)

        sumdf = pd.DataFrame(sums)
        st.markdown("### Summary (All Updates)")
        st.dataframe(sumdf, use_container_width=True)

        out = BytesIO()
        with pd.ExcelWriter(out, engine="xlsxwriter") as w:
            sumdf.to_excel(w, sheet_name="Summary", index=False)
            for label, dfw in sheets.items():
                safe = label[:28].replace(":","-").replace("/","-")
                dfw.to_excel(w, sheet_name=safe or "Update", index=False)
        st.download_button("Download Full Variance (Excel)", data=out.getvalue(),
                           file_name=f"nava_compare_full_{datetime.now().strftime('%Y%m%d')}.xlsx",
                           mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")

st.markdown("---")
st.caption("© 2025 Niti Consulting LLC · Terms: https://nava-analytics.ai/terms.html")
