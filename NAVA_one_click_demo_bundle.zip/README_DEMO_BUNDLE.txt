# NAVA Analytics AI — One‑Click Demo Bundle (No Stripe Needed)

This bundle includes your **demo marketing site** and the **app**. Pricing buttons open fake checkout pages that redirect to the app's welcome screen (no payment taken).

## Contents
- /site                  → Demo site with /demo-checkout pages and legal pages
- /app                   → Streamlit app skeleton (compare demo, consent hook)
- /supabase/functions    → stripe-webhook (placeholder for when you switch to Stripe)
- /supabase/sql          → schema.sql (placeholder)
- .env.template          → Rename to .env for the app
- Dockerfile, docker-compose.yml, run.sh/run.ps1

## Run locally (demo)
1) Install Docker Desktop.
2) Copy `.env.template` → `.env` (placeholders are fine for demo).
3) Start:
   ```bash
   ./run.sh
   ```
4) Open:
   - Site: http://localhost:8080
   - App:  http://localhost:8501

## Deploy the demo site
- **Vercel or Hostinger**: Deploy the `/site` folder as your publish directory.

## Switch to Stripe Test later
1) Create Stripe account, Products/Prices, and Payment Links.
2) Edit `/site/config/stripe-links.json`:
   - Set `"mode": "test"`
   - Replace `links.basic|starter|pro` with your Stripe Payment Links
3) Replace `supabase/functions/stripe-webhook/index.ts` with the full webhook code we prepared earlier and deploy it.
4) Set secrets in Supabase: `STRIPE_SECRET_KEY`, `STRIPE_WEBHOOK_SECRET`, `SUPABASE_URL`, `SUPABASE_SERVICE_ROLE_KEY`.
5) In Stripe → Webhooks, add your function endpoint and subscribe to the right events.

© 2025 Niti Consulting LLC. All rights reserved.
