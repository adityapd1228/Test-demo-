import React from 'react';
import { motion } from 'framer-motion';
import { Factory, Zap, Wind, Waves, Plane, Ship, Truck, Building, FlaskConical, Wrench, Sprout, Shield, Train } from 'lucide-react';
function IndustriesSection() {
  return <section id="industries" className="py-20 px-4 sm:px-6 lg:px-8 bg-black/30">
      <div className="max-w-7xl mx-auto text-center">
        <motion.div initial={{
        opacity: 0,
        y: 30
      }} whileInView={{
        opacity: 1,
        y: 0
      }} transition={{
        duration: 0.8
      }} className="mb-16">
          <h2 className="text-4xl md:text-5xl font-bold text-white mb-6">
            🏗 Built for High-Stakes, Complex Projects
          </h2>
          <p className="text-xl text-white/80 max-w-4xl mx-auto leading-relaxed mb-8">We help Planners, Schedulers, Project Controls Managers , Project Managers to provide valuable data driven project insights to executive management to make strategic business decisions and avoid potential risks</p>
          <p className="text-white/60 text-lg italic max-w-2xl mx-auto">
            If your project has tight deadlines, high risk, or complex dependencies — NAVA Analytics AI is built for you.
          </p>
        </motion.div>

        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-7 gap-6">
          {[{
          name: 'Mission Critical - Data Centers',
          icon: <Factory className="w-8 h-8 text-blue-400" />
        }, {
          name: 'Power and Utilities',
          icon: <Zap className="w-8 h-8 text-yellow-400" />
        }, {
          name: 'Renewable Energy',
          icon: <Wind className="w-8 h-8 text-green-400" />
        }, {
          name: 'Transportation - Heavy Civil P3 Type Projects',
          icon: <Truck className="w-8 h-8 text-purple-400" />
        }, {
          name: 'Rail Transportation',
          icon: <Train className="w-8 h-8 text-orange-500" />
        }, {
          name: 'Airports and Port of Authority',
          icon: <Plane className="w-8 h-8 text-sky-400" />
        }, {
          name: 'Water and Waste Water Treatment Plants',
          icon: <Waves className="w-8 h-8 text-cyan-400" />
        }, {
          name: 'Industrial & Manufacturing',
          icon: <Building className="w-8 h-8 text-orange-400" />
        }, {
          name: 'Oil & Gas',
          icon: <FlaskConical className="w-8 h-8 text-yellow-400" />
        }, {
          name: 'Mining',
          icon: <Wrench className="w-8 h-8 text-gray-400" />
        }, {
          name: 'Defense & Government Projects',
          icon: <Shield className="w-8 h-8 text-red-400" />
        }, {
          name: 'Commercial',
          icon: <Building className="w-8 h-8 text-indigo-400" />
        }, {
          name: 'High Rise',
          icon: <Building className="w-8 h-8 text-teal-400" />
        }, {
          name: 'Life Sciences',
          icon: <Sprout className="w-8 h-8 text-pink-400" />
        }].map((industry, index) => <motion.div key={industry.name} initial={{
          opacity: 0,
          y: 30
        }} whileInView={{
          opacity: 1,
          y: 0
        }} transition={{
          duration: 0.8,
          delay: index * 0.05
        }} className="flex flex-col items-center justify-center text-center p-4 rounded-xl bg-gradient-to-br from-white/5 to-white/0 border border-white/10 shadow-lg backdrop-blur-sm hover:scale-105 transition-all duration-300 h-32">
              {industry.icon}
              <p className="mt-3 text-white font-semibold text-sm">{industry.name}</p>
            </motion.div>)}
        </div>
      </div>
    </section>;
}
export default IndustriesSection;