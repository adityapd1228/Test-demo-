#!/usr/bin/env bash
set -e
echo "Starting NAVA (demo): site on http://localhost:8080, app on http://localhost:8501"
docker compose up --build
