import React from 'react';
import { Rocket, Mail, Linkedin, Twitter, Youtube } from 'lucide-react';

function FooterSection() {
  return (
    <footer className="py-12 px-4 sm:px-6 lg:px-8 bg-black/40 border-t border-white/10">
      <div className="max-w-7xl mx-auto">
        <div className="grid md:grid-cols-4 gap-8 mb-8">
          <div>
            <div className="flex items-center space-x-2 mb-4">
              <div className="w-8 h-8 bg-gradient-to-r from-blue-500 to-purple-600 rounded-lg flex items-center justify-center">
                <Rocket className="w-5 h-5 text-white" />
              </div>
              <span className="text-xl font-bold text-white">NAVA Analytics AI</span>
            </div>
            <p className="text-white/60">NAVA Analytics AI is a secure SaaS platform designed for construction scheduling professionals, powered by Python and GPT.</p>
          </div>
          
          <div>
            <span className="text-white font-semibold mb-4 block">Navigation</span>
            <div className="space-y-2">
              <p className="text-white/60 hover:text-white cursor-pointer transition-colors">Home</p>
              <p className="text-white/60 hover:text-white cursor-pointer transition-colors">Features</p>
              <p className="text-white/60 hover:text-white cursor-pointer transition-colors">Pricing</p>
              <p className="text-white/60 hover:text-white cursor-pointer transition-colors">Contact</p>
              <p className="text-white/60 hover:text-white cursor-pointer transition-colors">Privacy Policy</p>
            </div>
          </div>
          
          <div>
            <span className="text-white font-semibold mb-4 block">Contact</span>
            <div className="space-y-2">
              <div className="flex items-center text-white/60">
                <Mail className="w-4 h-4 mr-2" />
                <span>sales@nava-analytics.ai</span>
              </div>
              <div className="flex items-center text-white/60">
                <Mail className="w-4 h-4 mr-2" />
                <span>feedback@nava-analytics.ai</span>
              </div>
            </div>
          </div>
          
          <div>
            <span className="text-white font-semibold mb-4 block">Follow Us</span>
            <div className="flex space-x-4">
              <div className="w-10 h-10 bg-white/10 rounded-lg flex items-center justify-center hover:bg-white/20 cursor-pointer transition-colors">
                <Linkedin className="w-5 h-5 text-white" />
              </div>
              <div className="w-10 h-10 bg-white/10 rounded-lg flex items-center justify-center hover:bg-white/20 cursor-pointer transition-colors">
                <Twitter className="w-5 h-5 text-white" />
              </div>
              <div className="w-10 h-10 bg-white/10 rounded-lg flex items-center justify-center hover:bg-white/20 cursor-pointer transition-colors">
                <Youtube className="w-5 h-5 text-white" />
              </div>
            </div>
          </div>
        </div>
        
        <div className="border-t border-white/10 pt-8 text-center">
          <p className="text-white/60">© 2025 NAVA Analytics AI. All Rights Reserved.</p>
        </div>
      </div>
    </footer>
  );
}

export default FooterSection;