import React from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Toaster } from '@/components/ui/toaster';
import { useToast } from '@/components/ui/use-toast';
import { Rocket } from 'lucide-react';

// Import refactored sections
import HeroSection from '@/components/HeroSection';
import FeaturesSection from '@/components/FeaturesSection';
import HowItWorksSection from '@/components/HowItWorksSection';
import IndustriesSection from '@/components/IndustriesSection';
import PricingSection from '@/components/PricingSection';
import AboutSection from '@/components/AboutSection';
import FinalCTASection from '@/components/FinalCTASection';
import FooterSection from '@/components/FooterSection';

function App() {
  const { toast } = useToast();

  const handleDemoClick = () => {
    toast({
      title: "🚧 Demo Feature Coming Soon!",
      description: "This feature isn't implemented yet—but don't worry! You can request it in your next prompt! 🚀",
    });
  };

  const handleTrialClick = () => {
    toast({
      title: "🚧 Free Trial Coming Soon!",
      description: "This feature isn't implemented yet—but don't worry! You can request it in your next prompt! 🚀",
    });
  };

  const handleContactClick = () => {
    toast({
      title: "🚧 Contact Feature Coming Soon!",
      description: "This feature isn't implemented yet—but don't worry! You can request it in your next prompt! 🚀",
    });
  };

  return (
    <>
      <Helmet>
        <title>NAVA Analytics AI - Smarter Project Scheduling with AI-Powered Insights</title>
        <meta name="description" content="Transform your Primavera P6 schedules into actionable insights with the world's first Python-based, GPT-powered schedule analytics platform. Generate professional Schedule Narratives in minutes." />
      </Helmet>
      
      <div className="min-h-screen bg-gradient-to-br from-slate-900 via-blue-900 to-indigo-900">
        {/* Navigation */}
        <nav className="fixed top-0 w-full z-50 bg-black/20 backdrop-blur-lg border-b border-white/10">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="flex justify-between items-center h-16">
              <motion.div 
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                className="flex items-center space-x-2"
              >
                <div className="w-8 h-8 bg-gradient-to-r from-blue-500 to-purple-600 rounded-lg flex items-center justify-center">
                  <Rocket className="w-5 h-5 text-white" />
                </div>
                <span className="text-xl font-bold text-white">NAVA Analytics AI</span>
              </motion.div>
              
              <motion.div 
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                className="hidden md:flex items-center space-x-8"
              >
                <a href="#features" className="text-white/80 hover:text-white transition-colors">Features</a>
                <a href="#pricing" className="text-white/80 hover:text-white transition-colors">Pricing</a>
                <a href="#about" className="text-white/80 hover:text-white transition-colors">About</a>
                <Button onClick={handleDemoClick} variant="outline" className="border-white/20 text-white hover:bg-white/10">
                  Request Demo
                </Button>
              </motion.div>
            </div>
          </div>
        </nav>

        <HeroSection handleDemoClick={handleDemoClick} handleTrialClick={handleTrialClick} />
        <FeaturesSection />
        <HowItWorksSection />
        <IndustriesSection />
        <PricingSection handleTrialClick={handleTrialClick} handleContactClick={handleContactClick} />
        {/* Testimonials section removed as per user request */}
        <AboutSection />
        <FinalCTASection handleDemoClick={handleDemoClick} handleTrialClick={handleTrialClick} />
        <FooterSection />

        <Toaster />
      </div>
    </>
  );
}

export default App;