import React from 'react';
import { motion } from 'framer-motion';
import { Brain, BarChart3, FileText, Zap, Sparkles, Languages } from 'lucide-react';
function FeaturesSection() {
  return <section id="features" className="py-20 px-4 sm:px-6 lg:px-8 bg-black/20">
      <div className="max-w-7xl mx-auto">
        <motion.div initial={{
        opacity: 0,
        y: 30
      }} whileInView={{
        opacity: 1,
        y: 0
      }} transition={{
        duration: 0.8
      }} className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold text-white mb-6">
            💡 Why Choose NAVA Analytics AI?
          </h2>
        </motion.div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          <motion.div initial={{
          opacity: 0,
          y: 30
        }} whileInView={{
          opacity: 1,
          y: 0
        }} transition={{
          duration: 0.8,
          delay: 0.1
        }} className="bg-gradient-to-br from-blue-500/10 to-purple-500/10 rounded-2xl p-8 backdrop-blur-sm border border-white/10 hover:border-blue-400/30 transition-all duration-300 hover:transform hover:scale-105">
            <div className="w-16 h-16 bg-gradient-to-r from-blue-500 to-blue-600 rounded-2xl flex items-center justify-center mb-6">
              <Brain className="w-8 h-8 text-white" />
            </div>
            <h3 className="text-2xl font-bold text-white mb-4">AI-Driven Schedule Intelligence</h3>
            <p className="text-white/80">Instantly identify risks, float issues, and bottlenecks. Catch logic errors before they cause costly overruns — all in the cloud.</p>
          </motion.div>

          <motion.div initial={{
          opacity: 0,
          y: 30
        }} whileInView={{
          opacity: 1,
          y: 0
        }} transition={{
          duration: 0.8,
          delay: 0.2
        }} className="bg-gradient-to-br from-purple-500/10 to-pink-500/10 rounded-2xl p-8 backdrop-blur-sm border border-white/10 hover:border-purple-400/30 transition-all duration-300 hover:transform hover:scale-105">
            <div className="w-16 h-16 bg-gradient-to-r from-purple-500 to-purple-600 rounded-2xl flex items-center justify-center mb-6">
              <BarChart3 className="w-8 h-8 text-white" />
            </div>
            <h3 className="text-2xl font-bold text-white mb-4">Advanced Delay & DCMA Analysis</h3>
            <p className="text-white/80">Compare multiple schedule versions side-by-side with automated DCMA 14-point checks and run automated Schedule Forensic Analysis for Claims Support. All reports generated in real time via our SaaS engine.</p>
          </motion.div>

          <motion.div initial={{
          opacity: 0,
          y: 30
        }} whileInView={{
          opacity: 1,
          y: 0
        }} transition={{
          duration: 0.8,
          delay: 0.3
        }} className="bg-gradient-to-br from-green-500/10 to-emerald-500/10 rounded-2xl p-8 backdrop-blur-sm border border-white/10 hover:border-green-400/30 transition-all duration-300 hover:transform hover:scale-105">
            <div className="w-16 h-16 bg-gradient-to-r from-green-500 to-green-600 rounded-2xl flex items-center justify-center mb-6">
              <FileText className="w-8 h-8 text-white" />
            </div>
            <h3 className="text-2xl font-bold text-white mb-4">Python-Based GPT Narratives</h3>
            <p className="text-white/80">Generate professional-grade schedule narratives directly from .xer files in clear, client-ready language. Built on a custom Python + GPT workflow, hosted entirely on our SaaS platform.</p>
          </motion.div>

          <motion.div initial={{
          opacity: 0,
          y: 30
        }} whileInView={{
          opacity: 1,
          y: 0
        }} transition={{
          duration: 0.8,
          delay: 0.4
        }} className="bg-gradient-to-br from-orange-500/10 to-red-500/10 rounded-2xl p-8 backdrop-blur-sm border border-white/10 hover:border-orange-400/30 transition-all duration-300 hover:transform hover:scale-105">
            <div className="w-16 h-16 bg-gradient-to-r from-orange-500 to-orange-600 rounded-2xl flex items-center justify-center mb-6">
              <Zap className="w-8 h-8 text-white" />
            </div>
            <h3 className="text-2xl font-bold text-white mb-4">Seamless Primavera Integration</h3>
            <p className="text-white/80">Upload .xer files directly or connect to Oracle Primavera API for real-time updates without manual imports — from anywhere in the world.</p>
          </motion.div>
          
          <motion.div initial={{
          opacity: 0,
          y: 30
        }} whileInView={{
          opacity: 1,
          y: 0
        }} transition={{
          duration: 0.8,
          delay: 0.5
        }} className="bg-gradient-to-br from-yellow-500/10 to-amber-500/10 rounded-2xl p-8 backdrop-blur-sm border border-white/10 hover:border-yellow-400/30 transition-all duration-300 hover:transform hover:scale-105">
            <div className="w-16 h-16 bg-gradient-to-r from-yellow-500 to-yellow-600 rounded-2xl flex items-center justify-center mb-6">
              <Sparkles className="w-8 h-8 text-white" />
            </div>
            <h3 className="text-2xl font-bold text-white mb-4">Machine Learning (ML) Insights </h3>
            <p className="text-white/80">Our platform learns from historical schedule data to improve delay predictions, recommend schedule optimizations, and help you make data-driven decisions faster.</p>
          </motion.div>
          
          <motion.div initial={{
          opacity: 0,
          y: 30
        }} whileInView={{
          opacity: 1,
          y: 0
        }} transition={{
          duration: 0.8,
          delay: 0.6
        }} className="bg-gradient-to-br from-cyan-500/10 to-sky-500/10 rounded-2xl p-8 backdrop-blur-sm border border-white/10 hover:border-cyan-400/30 transition-all duration-300 hover:transform hover:scale-105">
            <div className="w-16 h-16 bg-gradient-to-r from-cyan-500 to-sky-600 rounded-2xl flex items-center justify-center mb-6">
              <Languages className="w-8 h-8 text-white" />
            </div>
            <h3 className="text-2xl font-bold text-white mb-4">Natural Language Processing  (NLP) Assistant</h3>
            <p className="text-white/80">Go beyond numbers. Our NLP engine analyzes project notes and reports to uncover hidden risks and sentiment trends that traditional analytics miss.</p>
          </motion.div>
        </div>
      </div>
    </section>;
}
export default FeaturesSection;