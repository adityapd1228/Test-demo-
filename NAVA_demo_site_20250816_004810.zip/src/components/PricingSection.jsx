import React from 'react';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { CheckCircle } from 'lucide-react';

function PricingSection({ handleTrialClick, handleContactClick }) {
  return (
    <section id="pricing" className="py-20 px-4 sm:px-6 lg:px-8">
      <div className="max-w-7xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          className="text-center mb-16"
        >
          <h2 className="text-4xl md:text-5xl font-bold text-white mb-6">
            💳 Pricing (SaaS Subscription Plans)
          </h2>
        </motion.div>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.1 }}
            className="bg-gradient-to-br from-gray-500/10 to-gray-600/10 rounded-2xl p-8 backdrop-blur-sm border border-white/10 hover:border-gray-400/30 transition-all duration-300"
          >
            <h3 className="text-2xl font-bold text-white mb-4">Basic</h3>
            <div className="mb-6">
              <span className="text-4xl font-bold text-white">$49</span>
              <span className="text-white/60">/month</span>
            </div>
            <ul className="space-y-3 mb-8">
              <li className="flex items-center text-white/80">
                <CheckCircle className="w-5 h-5 text-green-400 mr-3" />
                1 schedule upload/month
              </li>
              <li className="flex items-center text-white/80">
                <CheckCircle className="w-5 h-5 text-green-400 mr-3" />
                Basic AI schedule analysis
              </li>
              <li className="flex items-center text-white/80">
                <CheckCircle className="w-5 h-5 text-green-400 mr-3" />
                SaaS access from anywhere
              </li>
            </ul>
            <Button onClick={handleTrialClick} className="w-full bg-gradient-to-r from-gray-600 to-gray-700 hover:from-gray-700 hover:to-gray-800">
              Start Free Trial
            </Button>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="bg-gradient-to-br from-blue-500/10 to-purple-500/10 rounded-2xl p-8 backdrop-blur-sm border border-white/10 hover:border-blue-400/30 transition-all duration-300"
          >
            <h3 className="text-2xl font-bold text-white mb-4">Starter</h3>
            <div className="mb-6">
              <span className="text-4xl font-bold text-white">$99</span>
              <span className="text-white/60">/month</span>
            </div>
            <ul className="space-y-3 mb-8">
              <li className="flex items-center text-white/80">
                <CheckCircle className="w-5 h-5 text-green-400 mr-3" />
                10 uploads/month
              </li>
              <li className="flex items-center text-white/80">
                <CheckCircle className="w-5 h-5 text-green-400 mr-3" />
                Basic AI analysis & reporting
              </li>
              <li className="flex items-center text-white/80">
                <CheckCircle className="w-5 h-5 text-green-400 mr-3" />
                AI-powered schedule comparison module
              </li>
               <li className="flex items-center text-white/80">
                <CheckCircle className="w-5 h-5 text-green-400 mr-3" />
                SaaS subscription with automatic updates
              </li>
            </ul>
            <Button onClick={handleTrialClick} className="w-full bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700">
              Start Free Trial
            </Button>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.3 }}
            className="bg-gradient-to-br from-purple-500/20 to-pink-500/20 rounded-2xl p-8 backdrop-blur-sm border-2 border-purple-400/50 hover:border-purple-400/70 transition-all duration-300 relative"
          >
            <div className="absolute -top-4 left-1/2 transform -translate-x-1/2">
              <span className="bg-gradient-to-r from-purple-500 to-pink-500 text-white px-4 py-2 rounded-full text-sm font-semibold">
                Most Popular
              </span>
            </div>
            <h3 className="text-2xl font-bold text-white mb-4">Professional</h3>
            <div className="mb-6">
              <span className="text-4xl font-bold text-white">$249</span>
              <span className="text-white/60">/month</span>
            </div>
            <ul className="space-y-3 mb-8">
              <li className="flex items-center text-white/80">
                <CheckCircle className="w-5 h-5 text-green-400 mr-3" />
                Unlimited uploads
              </li>
              <li className="flex items-center text-white/80">
                <CheckCircle className="w-5 h-5 text-green-400 mr-3" />
                Delay analysis & DCMA checks
              </li>
              <li className="flex items-center text-white/80">
                <CheckCircle className="w-5 h-5 text-green-400 mr-3" />
                GPT-powered schedule narratives
              </li>
              <li className="flex items-center text-white/80">
                <CheckCircle className="w-5 h-5 text-green-400 mr-3" />
                AI-powered schedule comparison module
              </li>
              <li className="flex items-center text-white/80">
                <CheckCircle className="w-5 h-5 text-green-400 mr-3" />
                Claims Pro
              </li>
              <li className="flex items-center text-white/80">
                <CheckCircle className="w-5 h-5 text-green-400 mr-3" />
                Full SaaS features with priority updates
              </li>
            </ul>
            <Button onClick={handleTrialClick} className="w-full bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700">
              Start Free Trial
            </Button>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.4 }}
            className="bg-gradient-to-br from-orange-500/10 to-red-500/10 rounded-2xl p-8 backdrop-blur-sm border border-white/10 hover:border-orange-400/30 transition-all duration-300"
          >
            <h3 className="text-2xl font-bold text-white mb-4">Enterprise</h3>
            <div className="mb-6">
              <span className="text-4xl font-bold text-white">Custom</span>
              <span className="text-white/60"> Pricing</span>
            </div>
            <ul className="space-y-3 mb-8">
              <li className="flex items-center text-white/80">
                <CheckCircle className="w-5 h-5 text-green-400 mr-3" />
                Dedicated onboarding
              </li>
              <li className="flex items-center text-white/80">
                <CheckCircle className="w-5 h-5 text-green-400 mr-3" />
                API integration
              </li>
              <li className="flex items-center text-white/80">
                <CheckCircle className="w-5 h-5 text-green-400 mr-3" />
                Multi-project dashboards
              </li>
              <li className="flex items-center text-white/80">
                <CheckCircle className="w-5 h-5 text-green-400 mr-3" />
                Team access
              </li>
              <li className="flex items-center text-white/80">
                <CheckCircle className="w-5 h-5 text-green-400 mr-3" />
                AI-powered schedule comparison & Claims Pro
              </li>
               <li className="flex items-center text-white/80">
                <CheckCircle className="w-5 h-5 text-green-400 mr-3" />
                Secure enterprise-grade SaaS environment
              </li>
            </ul>
            <Button onClick={handleContactClick} variant="outline" className="w-full border-white/30 text-white hover:bg-white/10">
              Request Quote
            </Button>
          </motion.div>
        </div>
      </div>
    </section>
  );
}

export default PricingSection;