Write-Host "Starting NAVA (demo): site http://localhost:8080, app http://localhost:8501"
docker compose up --build
