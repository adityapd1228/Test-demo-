import React from 'react';
import { motion } from 'framer-motion';
import { Shield, Brain, Clock } from 'lucide-react';
function AboutSection() {
  return <section id="about" className="py-20 px-4 sm:px-6 lg:px-8">
      <div className="max-w-7xl mx-auto">
        <motion.div initial={{
        opacity: 0,
        y: 30
      }} whileInView={{
        opacity: 1,
        y: 0
      }} transition={{
        duration: 0.8
      }} className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold text-white mb-6">
            👥 The Team Behind NAVA Analytics AI
          </h2>
          <p className="text-xl text-white/80 max-w-4xl mx-auto leading-relaxed">Nava Analytics AI is tool developed by Scheduler for Schedulers</p>
          <p className="text-xl text-blue-300 font-semibold mt-6">
            Our mission: Use AI and automation to make schedule analysis faster, more accurate, and more actionable — starting with the world's first Python-based GPT Schedule Narrative Generator.
          </p>
        </motion.div>

        <div className="grid md:grid-cols-3 gap-8">
          <motion.div initial={{
          opacity: 0,
          y: 30
        }} whileInView={{
          opacity: 1,
          y: 0
        }} transition={{
          duration: 0.8,
          delay: 0.1
        }} className="text-center">
            <div className="w-20 h-20 bg-gradient-to-r from-blue-500 to-blue-600 rounded-full flex items-center justify-center mx-auto mb-6">
              <Shield className="w-10 h-10 text-white" />
            </div>
            <h3 className="text-2xl font-bold text-white mb-4">Expertise</h3>
            <p className="text-white/80">Passionate and Technology driven scheduler and database expert having experience working with various domains and industry leaders.</p>
          </motion.div>

          <motion.div initial={{
          opacity: 0,
          y: 30
        }} whileInView={{
          opacity: 1,
          y: 0
        }} transition={{
          duration: 0.8,
          delay: 0.2
        }} className="text-center">
            <div className="w-20 h-20 bg-gradient-to-r from-purple-500 to-purple-600 rounded-full flex items-center justify-center mx-auto mb-6">
              <Brain className="w-10 h-10 text-white" />
            </div>
            <h3 className="text-2xl font-bold text-white mb-4">AI Innovation</h3>
            <p className="text-white/80">Scheduler with self learned knowledge of python, AI / ML programming pushing the boundaries of schedule analytics automation saving on hours of analysis.</p>
          </motion.div>

          <motion.div initial={{
          opacity: 0,
          y: 30
        }} whileInView={{
          opacity: 1,
          y: 0
        }} transition={{
          duration: 0.8,
          delay: 0.3
        }} className="text-center">
            <div className="w-20 h-20 bg-gradient-to-r from-green-500 to-green-600 rounded-full flex items-center justify-center mx-auto mb-6">
              <Clock className="w-10 h-10 text-white" />
            </div>
            <h3 className="text-2xl font-bold text-white mb-4">Proven Results</h3>
            <p className="text-white/80">Track record of delivering projects on time and on budget across multiple industries.</p>
          </motion.div>
        </div>
      </div>
    </section>;
}
export default AboutSection;